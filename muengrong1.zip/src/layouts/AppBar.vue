<template>
  <v-card class="overflow-hidden">
    <v-app-bar
      absolute
      color="indigo darken-2"
      dark
      shrink-on-scroll
      prominent
      scroll-target="#scrolling-techniques"
    >
      <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>

      <v-toolbar-title>Title</v-toolbar-title>

      <v-spacer></v-spacer>

      <v-btn icon>
        <v-icon>mdi-magnify</v-icon>
      </v-btn>

      <v-btn icon>
        <v-icon>mdi-heart</v-icon>
      </v-btn>

      <v-btn icon>
        <v-icon>mdi-dots-vertical</v-icon>
      </v-btn>
    </v-app-bar>
    <v-navigation-drawer v-model="drawer" absolute temporary>
      <v-list dense nav class="py-0">
        <v-list-item two-line :class="miniVariant && 'px-0'">
          <v-list-item-avatar>
            <img src="https://randomuser.me/api/portraits/men/81.jpg" />
          </v-list-item-avatar>

          <v-list-item-content>
            <v-list-item-title>Application</v-list-item-title>
            <v-list-item-subtitle>Subtext</v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>

        <v-divider></v-divider>

        <v-list-item v-for="item in items" :key="item.title" link @click="linkTo(item.link)">
          <v-list-item-icon>
            <v-icon>{{ item.icon }}</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>{{ item.title }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>

    <v-sheet id="scrolling-techniques" class="overflow-y-auto" max-height="650">
      <v-content style="height: 1000px;">
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <router-view></router-view>
      </v-content>
    </v-sheet>

    <v-bottom-navigation :value="activeBtn" grow color="teal">
      <v-btn to="/search">
        <span>Search</span>
        <v-icon>mdi-history</v-icon>
      </v-btn>

      <v-btn to="/booking">
        <span>My Booking</span>
        <v-icon>mdi-heart</v-icon>
      </v-btn>

      <v-btn to="/copon">
        <span>Copon</span>
        <v-icon>mdi-map-marker</v-icon>
      </v-btn>
    </v-bottom-navigation>
  </v-card>
</template>

<script>
import Firebase from 'firebase'
export default {
  data() {
    return {
      drawer: true,
      items: [
        { title: 'Dashboard', icon: 'mdi-view-dashboard', link: '/booking' },
        { title: 'Photos', icon: 'mdi-image', link: '/dashodoard' },
        { title: 'About', icon: 'mdi-help-box', link: '/prevent' }
      ],
      color: 'primary',
      colors: ['primary', 'blue', 'success', 'red', 'teal'],
      right: true,
      miniVariant: false,
      expandOnHover: false,
      background: false
    }
  },
  computed: {
    bg() {
      return this.background
        ? 'https://cdn.vuetifyjs.com/images/backgrounds/bg-2.jpg'
        : undefined
    }
  },
  mounted: function() {
    this.activeLink = this.$route.path
  },
  methods: {
    linkTo(path) {
      console.log(this.activeLink)
      if (path != this.$route.path) {
        this.$router.push(path)
        this.activeLink = this.$route.path
      }
    }
  },
  watch: {
    $route(to) {
      this.activeLink = to.path
    }
  }
}
</script>