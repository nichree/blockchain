import Vue from 'vue'
import Router from 'vue-router'
import AppBar from './layouts/AppBar.vue'

import Booking from './views/Booking'
import Copon from './views/Copon'
import Search from './views/Search'
Vue.use(Router)

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  linkActiveClass: 'active',
  routes: [
    {
      path: '/',
      component: AppBar,
      children: [
        {
          path: '/booking',
          alias: '/',
          name: 'booking',
          component: Booking
        },
        {
          path: '/copon',
          name: 'copon',
          component: Copon
        },
        {
          path: '/search',
          name: 'search',
          component: Search
        }
      ]
    }
  ]
})
