<template>
  <v-container>
    <v-card class="mx-auto" max-width="1000">
      <v-img
        src="https://cdn.vuetifyjs.com/images/cards/sunshine.jpg"
        height="200px"
        class="white--text align-end"
      >
        <v-card-title>The Chiang Rai Hotel</v-card-title>
      </v-img>

      <v-card-actions>
        <v-btn class="m2" color="primary" text>Cancle Booking</v-btn>

        <v-spacer></v-spacer>

        <v-btn icon @click="show = !show">
          <v-icon>{{ show ? 'mdi-chevron-up' : 'mdi-chevron-down' }}</v-icon>
        </v-btn>
      </v-card-actions>

      <v-expand-transition>
        <div v-show="show">
          <v-divider></v-divider>

          <v-card-text>
            Date : 14/02/2020<br />
            13:55 Don Mueang International Airport DMK<br />
            .<br />
            .<br />
            Travel time: 1 h 25 m<br />
            .<br />
            .<br />
            15:20 Mae Fah Luang - Chiang Rai International Airport CEI<br />
          </v-card-text>
        </div>
      </v-expand-transition>
    </v-card>
    <br/>
    <v-card class="mx-auto" max-width="1000">
      <v-img
        src="https://blog.traveloka.com/source/uploads/sites/5/2017/05/nokair_cover.jpg"
        height="200px"
        class="white--text align-end"
      >
        <v-card-title>Nok Flexi</v-card-title>
      </v-img>

      <v-card-actions>
        <v-btn class="m2" color="primary" text>Cancle Booking</v-btn>

        <v-spacer></v-spacer>

        <v-btn icon @click="show = !show">
          <v-icon>{{ show ? 'mdi-chevron-up' : 'mdi-chevron-down' }}</v-icon>
        </v-btn>
      </v-card-actions>

      <v-expand-transition>
        <div v-show="show">
          <v-divider></v-divider>

          <v-card-text>
            519 Suk Sathit, ตำบล เวียง Mueang Chiang Rai District, Chiang Rai 57000•053 711 266
            <br />Check in : 14/02/2020
            <br />Check out : 15/02/2020
          </v-card-text>
        </div>
      </v-expand-transition>
    </v-card>
  </v-container>
</template>
<script>
export default {
  data() {
    return {
      show: false
    }
  }
}
</script>

