<template>
  <div slot="media">
    <v-container>
      <v-row align="center">
        <v-col class="d-flex" cols="12" sm="6">
          <v-select :items="Origin" :menu-props="{ offsetY: true }" label="Origin"></v-select>
        </v-col>
        <v-col class="d-flex" cols="12" sm="6">
          <v-select :items="Destination" :menu-props="{ offsetY: true }" label="Destination"></v-select>
        </v-col>

        <v-col class="d-flex" cols="12" sm="6">
          <v-menu
            ref="menu"
            v-model="menu"
            :close-on-content-click="false"
            :return-value.sync="date"
            transition="scale-transition"
            offset-y
            min-width="290px"
          >
            <template v-slot:activator="{ on }">
              <v-text-field v-model="date" label="Depart Date" readonly v-on="on"></v-text-field>
            </template>
            <v-date-picker v-model="date" no-title scrollable>
              <v-spacer></v-spacer>
              <v-btn text color="primary" @click="menu = false">Cancel</v-btn>
              <v-btn text color="primary" @click="$refs.menu.save(date)">OK</v-btn>
            </v-date-picker>
          </v-menu>
        </v-col>
        <v-col class="d-flex" cols="12" sm="6">
          <v-menu
            ref="menu"
            v-model="menu2"
            :close-on-content-click="false"
            transition="scale-transition"
            offset-y
            min-width="290px"
          >
            <template v-slot:activator="{ on }">
              <v-text-field v-model="date" label="Return Date" readonly v-on="on"></v-text-field>
            </template>
            <v-date-picker v-model="date" no-title scrollable>
              <v-spacer></v-spacer>
              <v-btn text color="primary" @click="menu2 = false">Cancel</v-btn>
              <v-btn text color="primary" @click="$refs.menu2.save(date)">OK</v-btn>
            </v-date-picker>
          </v-menu>
        </v-col>

        <v-col>
          <v-text-field label="Promo Code"></v-text-field>
        </v-col>
      </v-row>
      <v-row align="center">
        <v-col align="center">
          <div class="my-2">
            <v-btn depressed color="primary">Primary</v-btn>
          </div>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>
<script>
export default {
  data: () => ({
    Origin: ['Bangkok', 'Amnat Charoen', '	Ang Thong', 'Bueng Kan'],
    Destination: ['Chiang Rai', 'Lampang', 'Nan', 'Phayao'],
    date: new Date().toISOString().substr(0, 10),
    menu: false,
    menu2: false
  })
}
</script>